import Dashboard from "@/components/Dashboard";

export default function Home() {
  return <main className="p-4"><Dashboard /></main>;
}
