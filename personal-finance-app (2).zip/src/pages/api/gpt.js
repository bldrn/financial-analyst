
export default function handler(req, res) {
  if (req.method === 'POST') {
    const { contract_type, country, context } = req.body;
    const mock = `Generated ${contract_type} for ${country}:\n\n${context}\n\n[Legal content goes here...]`;
    return res.status(200).json({ content: mock });
  }
  res.status(405).end();
}
