
let memory = [];

export default function handler(req, res) {
  if (req.method === 'GET') {
    res.status(200).json(memory.slice(-10));
  } else if (req.method === 'POST') {
    const tx = req.body;
    memory.push(tx);
    res.status(200).json({ message: "Transaction added." });
  } else {
    res.status(405).end();
  }
}
