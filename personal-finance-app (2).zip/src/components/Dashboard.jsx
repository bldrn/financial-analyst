import React, { useState } from "react";

export default function Dashboard() {
  const [filters, setFilters] = useState({ category: "", type: "", startDate: "", endDate: "" });
  const [transactions, setTransactions] = useState([]);
  const [docForm, setDocForm] = useState({ contract_type: "", country: "", context: "" });
  const [generatedDoc, setGeneratedDoc] = useState("");

  return (
    <>
      <div className="p-4 border rounded bg-white shadow">
        <h2 className="text-lg font-semibold mb-4">Recent Transactions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <input
            type="text"
            placeholder="Category"
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            className="w-full px-3 py-2 border rounded"
          />
          <select
            value={filters.type}
            onChange={(e) => setFilters({ ...filters, type: e.target.value })}
            className="w-full px-3 py-2 border rounded"
          >
            <option value="">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>
          <input
            type="date"
            value={filters.startDate}
            onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
            className="w-full px-3 py-2 border rounded"
          />
          <input
            type="date"
            value={filters.endDate}
            onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
            className="w-full px-3 py-2 border rounded"
          />
        </div>
        <ul className="divide-y border rounded text-sm">
          {transactions.length > 0 ? (
            transactions.map((tx, idx) => (
              <li key={idx} className="px-3 py-2">
                <div className="font-semibold text-gray-800">{tx.type.toUpperCase()}: {tx.amount}</div>
                <div className="text-gray-600">Category: {tx.category}</div>
                {tx.note && <div className="text-gray-500 italic">Note: {tx.note}</div>}
              </li>
            ))
          ) : (
            <li className="px-3 py-2 text-gray-500">No transactions found.</li>
          )}
        </ul>
      </div>

      <div className="p-4 border rounded bg-white shadow mt-6">
        <h2 className="text-lg font-semibold mb-4">GPT Document Assistant</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <input
            type="text"
            placeholder="Contract Type"
            value={docForm.contract_type}
            onChange={(e) => setDocForm({ ...docForm, contract_type: e.target.value })}
            className="w-full px-3 py-2 border rounded"
          />
          <input
            type="text"
            placeholder="Country"
            value={docForm.country}
            onChange={(e) => setDocForm({ ...docForm, country: e.target.value })}
            className="w-full px-3 py-2 border rounded"
          />
        </div>
        <textarea
          rows={4}
          placeholder="Context or description for GPT"
          value={docForm.context}
          onChange={(e) => setDocForm({ ...docForm, context: e.target.value })}
          className="w-full px-3 py-2 border rounded mb-4"
        ></textarea>
        <button
          onClick={() => setGeneratedDoc(docForm.context)}
          className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded shadow"
        >
          Generate Document
        </button>
        {generatedDoc && (
          <div className="mt-6 space-y-2">
            <div className="flex justify-between items-center">
              <h3 className="text-md font-semibold">Generated Document</h3>
              <div className="space-x-2">
                <button className="text-sm bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded">Edit</button>
                <button className="text-sm bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded">Export</button>
                <button className="text-sm bg-purple-600 hover:bg-purple-700 text-white px-2 py-1 rounded">Validate</button>
              </div>
            </div>
            <div className="p-3 border rounded bg-gray-50 text-sm whitespace-pre-wrap">
              {generatedDoc}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
