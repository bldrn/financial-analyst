# Personal Finance Dashboard

This app tracks transactions and helps generate legal documents via GPT.

## Setup
```bash
npm install
npm run dev
```

## Deploy
Push to GitHub and connect to Vercel.